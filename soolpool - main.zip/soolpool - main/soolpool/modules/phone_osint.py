import subprocess
import shutil
import re

try:
    import phonenumbers
    from phonenumbers import geocoder, carrier, timezone as pn_timezone
except ImportError:
    phonenumbers = None


def phoneinfoga_scan(number, timeout=90):
    if not shutil.which("phoneinfoga"):
        return {"ok": False, "error": "phoneinfoga не установлен"}
    clean = number.lstrip("+").replace(" ", "").replace("-", "")
    try:
        proc = subprocess.run(
            ["phoneinfoga", "scan", "-n", clean, "--no-color"],
            capture_output=True, text=True, timeout=timeout,
        )
        return {"ok": True, "raw": proc.stdout + proc.stderr}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "таймаут"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def manual_dorks(number):
    clean = re.sub(r"\D", "", number)
    if not clean:
        return []
    variants = [clean, "+" + clean, number, number.replace("+", "%2B")]
    dorks = []
    for v in set(variants):
        dorks.extend([
            f"https://www.google.com/search?q=%22{v}%22",
            f"https://yandex.ru/search/?text=%22{v}%22",
            f"https://duckduckgo.com/?q=%22{v}%22",
            f"https://www.bing.com/search?q=%22{v}%22",
            f"https://www.facebook.com/search/top?q={v}",
            f"https://twitter.com/search?q=%22{v}%22",
            f"https://www.linkedin.com/search/results/all/?keywords={v}",
            f"https://t.me/s/{v}",
            f"https://vk.com/search?c%5Bq%5D={v}",
            f"https://github.com/search?q={v}&type=users",
        ])
    return dorks


def analyze_phone(number, region="RU"):
    if not phonenumbers:
        return {"ok": False, "error": "phonenumbers не установлен"}
    try:
        num = phonenumbers.parse(number, region)
    except phonenumbers.NumberParseException as e:
        return {"ok": False, "error": str(e)}

    result = {
        "valid": phonenumbers.is_valid_number(num),
        "possible": phonenumbers.is_possible_number(num),
        "e164": phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.E164),
        "international": phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
        "national": phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.NATIONAL),
        "rfc3966": phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.RFC3966),
        "country_code": num.country_code,
        "region": geocoder.description_for_number(num, "ru") or geocoder.description_for_number(num, "en"),
        "carrier": carrier.name_for_number(num, "ru") or carrier.name_for_number(num, "en"),
        "timezones": list(pn_timezone.time_zones_for_number(num)),
    }
    ntype = phonenumbers.number_type(num)
    types = {
        0: "FIXED_LINE", 1: "MOBILE", 2: "FIXED_LINE_OR_MOBILE",
        3: "TOLL_FREE", 4: "PREMIUM_RATE", 5: "SHARED_COST",
        6: "VOIP", 7: "PERSONAL_NUMBER", 8: "PAGER",
        9: "UAN", 10: "VOICEMAIL", -1: "UNKNOWN",
    }
    result["type"] = types.get(ntype, "UNKNOWN")
    result["ok"] = True
    return result