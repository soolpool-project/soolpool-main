import subprocess
import shutil
import json
import socket
import dns.resolver


def run_holehe(email, timeout=90):
    if not shutil.which("holehe"):
        return {"ok": False, "error": "holehe не установлен"}
    try:
        proc = subprocess.run(
            ["holehe", email, "--only-used", "--no-color"],
            capture_output=True, text=True, timeout=timeout,
        )
        output = proc.stdout + proc.stderr
        found = []
        for line in output.splitlines():
            line = line.strip()
            if line.startswith("[+]"):
                found.append(line.replace("[+]", "").strip())
        return {"ok": True, "platforms": found, "raw": output}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "таймаут 90s"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def run_ghunt(email, timeout=60):
    if not shutil.which("ghunt"):
        return {"ok": False, "error": "ghunt не установлен"}
    try:
        proc = subprocess.run(
            ["ghunt", "email", email, "--json", "/tmp/ghunt_out.json"],
            capture_output=True, text=True, timeout=timeout,
        )
        output = proc.stdout + proc.stderr
        data = None
        try:
            with open("/tmp/ghunt_out.json") as f:
                data = json.load(f)
        except Exception:
            pass
        if "cookies" in output.lower() or "not logged" in output.lower():
            return {"ok": False, "error": "требуется ghunt login"}
        return {"ok": True, "data": data, "raw": output}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "таймаут"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def check_emailrep(email, timeout=10):
    try:
        import requests
        r = requests.get(
            f"https://emailrep.io/{email}",
            headers={"User-Agent": "SOOLPOOL-OSINT"},
            timeout=timeout,
        )
        if r.status_code == 200:
            return {"ok": True, "data": r.json()}
        if r.status_code == 429:
            return {"ok": False, "error": "rate limit"}
        return {"ok": False, "error": f"HTTP {r.status_code}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def check_mx(email, timeout=5):
    if "@" not in email:
        return {"ok": False, "error": "некорректный email"}
    domain = email.split("@", 1)[1]
    result = {"domain": domain, "mx": [], "a": None}
    try:
        answers = dns.resolver.resolve(domain, "MX", lifetime=timeout)
        for a in answers:
            result["mx"].append(str(a.exchange).rstrip("."))
    except Exception:
        pass
    try:
        result["a"] = socket.gethostbyname(domain)
    except Exception:
        pass
    return {"ok": True, **result}