import requests

HIBP_URL = "https://haveibeenpwned.com/api/v3/breachedaccount/{email}"


def check_hibp(email, api_key=None, timeout=10):
    headers = {
        "User-Agent": "SOOLPOOL-OSINT",
        "hibp-api-key": api_key or "",
    }
    try:
        r = requests.get(
            HIBP_URL.format(email=email),
            headers=headers,
            timeout=timeout,
            params={"truncateResponse": "false"},
        )
        if r.status_code == 200:
            return {"ok": True, "breaches": r.json()}
        if r.status_code == 404:
            return {"ok": True, "breaches": []}
        if r.status_code == 401:
            return {"ok": False, "error": "Требуется API-ключ HIBP"}
        if r.status_code == 429:
            return {"ok": False, "error": "Rate limit"}
        return {"ok": False, "error": f"HTTP {r.status_code}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}