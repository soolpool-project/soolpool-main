# -*- coding: utf-8 -*-
import os
import sys
import time
import socket
import ssl
import re
import json
import shutil
import threading
import subprocess
import dns.resolver
from datetime import datetime

try:
    import requests
    import whois
    from colorama import Fore, Style, init
    from bs4 import BeautifulSoup
    import phonenumbers
    from phonenumbers import geocoder, carrier, timezone as pn_timezone
    from email_validator import validate_email, EmailNotValidError
    init(autoreset=True)
except ImportError as e:
    print(f"[!] Установите зависимости: pip install -r requirements.txt ({e})")
    sys.exit(1)

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

O  = Fore.LIGHTYELLOW_EX
O2 = Fore.YELLOW
O3 = Fore.LIGHTRED_EX
W  = Fore.WHITE
GR = Fore.LIGHTBLACK_EX
G  = Fore.GREEN
R  = Fore.RED
RESET = Style.RESET_ALL
BOLD = Style.BRIGHT


def clear():
    os.system('cls' if os.name == 'nt' else 'clear')


def typewriter(text, delay=0.012, color=O2):
    for ch in text:
        sys.stdout.write(color + ch)
        sys.stdout.flush()
        time.sleep(delay)
    print(RESET)


def loading_animation(text="Загрузка", duration=1.4):
    frames = ["◐", "◓", "◑", "◒"]
    end = time.time() + duration
    i = 0
    while time.time() < end:
        sys.stdout.write(f"\r  {O2}{frames[i % 4]} {text}...{RESET}")
        sys.stdout.flush()
        time.sleep(0.1)
        i += 1
    sys.stdout.write(f"\r{' ' * (len(text) + 20)}\r")


def progress_bar(text="Обработка", duration=1.2, width=42):
    print(f"  {O2}{text}{RESET}")
    for i in range(width + 1):
        p = int((i / width) * 100)
        bar = "▰" * i + "▱" * (width - i)
        color = O if p < 50 else O2 if p < 90 else O3
        sys.stdout.write(f"\r  {color}[{bar}] {p:3d}%{RESET}")
        sys.stdout.flush()
        time.sleep(duration / width)
    print()


def banner():
    clear()
    print(f"""{BOLD}{O3}
   ╔══════════════════════════════════════════════════════════════╗
   ║                                                              ║
   ║   ███████╗ ██████╗  ██████╗ ██╗     ██████╗  ██████╗  ██╗    ║
   ║   ██╔════╝██╔═══██╗██╔═══██╗██║     ██╔══██╗██╔═══██╗██║    ║
   ║   ███████╗██║   ██║██║   ██║██║     ██████╔╝██║   ██║██║    ║
   ║   ╚════██║██║   ██║██║   ██║██║     ██╔═══╝ ██║   ██║██║    ║
   ║   ███████║╚██████╔╝╚██████╔╝███████╗██║     ╚██████╔╝███████╗║
   ║   ╚══════╝ ╚═════╝  ╚═════╝ ╚══════╝╚═╝      ╚═════╝ ╚══════╝║
   ║                                                              ║
   ╚══════════════════════════════════════════════════════════════╝
{RESET}{O2}{BOLD}       ▲▽▲  OSINT FRAMEWORK v3.0 · Email & Phone  ▲▽▲{RESET}
{GR}          [ Domain · Web · Email · Phone · Public sources only ]{RESET}
""")
    typewriter(f"  {O2}▸ Модули загружены. Только публичные источники.{RESET}", 0.006)


def section(title):
    print(f"\n{O3}  ╭{'─' * 58}╮{RESET}")
    print(f"{O3}  │ {BOLD}{O}{title:<56}{O3} │{RESET}")
    print(f"{O3}  ╰{'─' * 58}╯{RESET}")


def ok(m):   print(f"  {G}[✓]{RESET} {W}{m}{RESET}")
def info(m): print(f"  {O2}[i]{RESET} {W}{m}{RESET}")
def warn(m): print(f"  {O}[!]{RESET} {W}{m}{RESET}")
def err(m):  print(f"  {R}[✗]{RESET} {W}{m}{RESET}")


def clean_url(url):
    if not url.startswith(("http://", "https://")):
        url = "http://" + url
    return url


def safe_request(url, timeout=8):
    headers = {"User-Agent": "Mozilla/5.0 SOOLPOOL/3.0"}
    return requests.get(url, headers=headers, timeout=timeout,
                        verify=False, allow_redirects=True)


DISPOSABLE_DOMAINS = {
    "tempmail.com", "10minutemail.com", "guerrillamail.com", "mailinator.com",
    "throwawaymail.com", "yopmail.com", "trashmail.com", "sharklasers.com",
    "getnada.com", "temp-mail.org", "fakeinbox.com", "dispostable.com",
    "maildrop.cc", "mintemail.com", "spam4.me", "grr.la", "tempinbox.com",
    "throwaway.email", "mailnesia.com", "tempr.email", "discard.email",
    "spamgourmet.com", "mohmal.com", "emailondeck.com", "burnermail.io",
    "mailsac.com", "inboxbear.com", "moakt.com",
}

SUSPICIOUS_KEYWORDS = [
    "test", "fake", "spam", "admin", "noreply", "no-reply",
    "donotreply", "abuse", "example", "invalid", "dump",
]


def f_whois():
    section("1. WHOIS Lookup")
    d = input(f"  {O2}Домен ▸ {RESET}").strip()
    loading_animation("WHOIS")
    try:
        w = whois.whois(d)
        for k, v in {"Домен": w.domain_name, "Регистратор": w.registrar,
                     "Создан": w.creation_date, "Истекает": w.expiration_date,
                     "Обновлен": w.updated_date, "NS": w.name_servers,
                     "Страна": w.country, "Email": w.emails}.items():
            if v:
                ok(f"{k}: {v}")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_dns():
    section("2. DNS Records")
    d = input(f"  {O2}Домен ▸ {RESET}").strip()
    for t in ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA"]:
        try:
            answers = dns.resolver.resolve(d, t, lifetime=5)
            print(f"  {O2}[{t}]{RESET}")
            for a in answers:
                print(f"     {GR}└─{RESET} {a.to_text()}")
        except Exception:
            print(f"  {R}[{t}] — не найдено{RESET}")


def f_ip_info():
    section("3. IP Information")
    ip = input(f"  {O2}IP/домен ▸ {RESET}").strip()
    loading_animation("Геолокация")
    try:
        ip_addr = socket.gethostbyname(ip)
        info(f"IP: {ip_addr}")
        r = requests.get(
            f"http://ip-api.com/json/{ip_addr}?fields=status,country,regionName,"
            "city,zip,lat,lon,timezone,isp,org,as,query", timeout=8).json()
        if r.get("status") == "success":
            for k, v in r.items():
                if k != "status":
                    print(f"  {O2}{k:12}{RESET}: {v}")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_reverse_dns():
    section("4. Reverse DNS")
    ip = input(f"  {O2}IP ▸ {RESET}").strip()
    try:
        h = socket.gethostbyaddr(ip)
        ok(f"Hostname: {h[0]}")
        ok(f"Aliases: {h[1]}")
        ok(f"Addresses: {h[2]}")
    except Exception as e:
        err(f"Не найдено: {e}")


def f_headers():
    section("5. HTTP Headers")
    url = input(f"  {O2}URL ▸ {RESET}").strip()
    loading_animation("Запрос")
    try:
        r = safe_request(clean_url(url))
        ok(f"Status: {r.status_code}")
        for k, v in r.headers.items():
            print(f"  {O2}{k}{RESET}: {v}")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_ssl():
    section("6. SSL Certificate")
    host = input(f"  {O2}Домен ▸ {RESET}").strip()
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with ctx.wrap_socket(socket.socket(), server_hostname=host) as s:
            s.settimeout(6)
            s.connect((host, 443))
            cert = s.getpeercert()
        ok(f"Subject: {dict(x[0] for x in cert['subject'])}")
        ok(f"Issuer: {dict(x[0] for x in cert['issuer'])}")
        ok(f"Valid from: {cert['notBefore']}")
        ok(f"Valid to: {cert['notAfter']}")
        ok(f"SAN: {cert.get('subjectAltName')}")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_robots():
    section("7. Robots.txt")
    url = input(f"  {O2}URL ▸ {RESET}").strip()
    try:
        r = safe_request(clean_url(url) + "/robots.txt")
        if r.status_code == 200:
            print(f"{GR}{r.text[:3000]}{RESET}")
        else:
            warn(f"Не найден (HTTP {r.status_code})")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_sitemap():
    section("8. Sitemap.xml")
    url = input(f"  {O2}URL ▸ {RESET}").strip()
    try:
        r = safe_request(clean_url(url) + "/sitemap.xml")
        if r.status_code == 200:
            urls = re.findall(r"<loc>(.*?)</loc>", r.text)
            ok(f"Найдено URL: {len(urls)}")
            for u in urls[:30]:
                print(f"  {GR}└─{RESET} {u}")
        else:
            warn(f"Не найден ({r.status_code})")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_ports():
    section("9. Port Scanner")
    host = input(f"  {O2}Хост ▸ {RESET}").strip()
    common = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 3306, 3389,
              5432, 5900, 6379, 8080, 8443, 27017]
    info(f"Сканируем {len(common)} портов...")

    def scan(p):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.8)
            if s.connect_ex((host, p)) == 0:
                print(f"  {G}[OPEN]{RESET} {O2}{p}{RESET}")
            s.close()
        except Exception:
            pass

    ts = [threading.Thread(target=scan, args=(p,)) for p in common]
    for t in ts:
        t.start()
    for t in ts:
        t.join()


def f_subdomains():
    section("10. Subdomain Finder")
    domain = input(f"  {O2}Домен ▸ {RESET}").strip()
    subs = ["www", "mail", "ftp", "admin", "api", "dev", "test", "staging",
            "blog", "shop", "forum", "cdn", "static", "vpn", "ns1", "ns2",
            "smtp", "pop", "imap", "webmail", "cpanel", "portal", "app",
            "m", "support", "docs", "git", "gitlab", "jenkins"]
    info(f"Проверяем {len(subs)} поддоменов...")

    def check(s):
        full = f"{s}.{domain}"
        try:
            ip = socket.gethostbyname(full)
            print(f"  {G}[✓]{RESET} {O2}{full:35}{RESET} ▸ {ip}")
        except Exception:
            pass

    ts = [threading.Thread(target=check, args=(s,)) for s in subs]
    for t in ts:
        t.start()
    for t in ts:
        t.join()


def f_website_errors():
    section("11. Website Error Checker")
    url = input(f"  {O2}URL ▸ {RESET}").strip()
    loading_animation("Анализ")
    try:
        r = safe_request(clean_url(url))
        ok(f"HTTP статус: {r.status_code}")
        errors = []
        if r.status_code >= 400:
            errors.append(f"HTTP ошибка: {r.status_code}")
        soup = BeautifulSoup(r.text, "html.parser")
        for tag in ["center", "font", "marquee", "blink", "frame", "frameset"]:
            if soup.find(tag):
                errors.append(f"Устаревший тег <{tag}>")
        if not soup.find("meta", attrs={"name": "description"}):
            errors.append("Нет meta description")
        if not soup.find("meta", attrs={"name": "viewport"}):
            errors.append("Нет meta viewport")
        if not soup.title or not soup.title.string:
            errors.append("Нет <title>")
        imgs = [i for i in soup.find_all("img") if not i.get("alt")]
        if imgs:
            errors.append(f"{len(imgs)} img без alt")
        if r.url.startswith("https") and "http://" in r.text:
            errors.append("Смешанный контент")
        if len(soup.find_all("script")) > 30:
            errors.append(f"Много скриптов: {len(soup.find_all('script'))}")
        if errors:
            warn("Проблемы:")
            for e in errors:
                print(f"  {R}✗ {e}{RESET}")
        else:
            ok("Критичных ошибок нет")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_technologies():
    section("12. Technologies Detector")
    url = input(f"  {O2}URL ▸ {RESET}").strip()
    try:
        r = safe_request(clean_url(url))
        h = r.headers
        text = r.text.lower()
        tech = []
        if "server" in h:
            tech.append(f"Server: {h['server']}")
        if "x-powered-by" in h:
            tech.append(f"Powered: {h['x-powered-by']}")
        patterns = {"WordPress": ["wp-content", "wp-includes"],
                    "Joomla": ["joomla", "/components/com_"],
                    "Drupal": ["drupal", "sites/default"],
                    "React": ["react", "_react"],
                    "Vue.js": ["vue.js", "vue.min.js"],
                    "Angular": ["ng-app", "angular"],
                    "Bootstrap": ["bootstrap"], "jQuery": ["jquery"],
                    "Cloudflare": ["cloudflare"], "Nginx": ["nginx"],
                    "Apache": ["apache"]}
        for name, keys in patterns.items():
            if any(k in text or k in str(h).lower() for k in keys):
                tech.append(name)
        if tech:
            for t in tech:
                print(f"  {G}[✓]{RESET} {t}")
        else:
            warn("Не определено")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_emails_extract():
    section("13. Email Extractor (from site)")
    url = input(f"  {O2}URL ▸ {RESET}").strip()
    try:
        r = safe_request(clean_url(url))
        emails = set(re.findall(
            r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", r.text))
        if emails:
            ok(f"Найдено: {len(emails)}")
            for e in emails:
                print(f"  {GR}└─{RESET} {e}")
        else:
            warn("Не найдено")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_phones_extract():
    section("14. Phone Extractor (from site)")
    url = input(f"  {O2}URL ▸ {RESET}").strip()
    try:
        r = safe_request(clean_url(url))
        phones = set(re.findall(r"\+?\d[\d\s\-\(\)]{7,}\d", r.text))
        phones = [p for p in phones if 9 <= len(re.sub(r"\D", "", p)) <= 15]
        if phones:
            ok(f"Найдено: {len(phones)}")
            for p in list(phones)[:30]:
                print(f"  {GR}└─{RESET} {p}")
        else:
            warn("Не найдено")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_ping():
    section("15. Ping")
    host = input(f"  {O2}Хост ▸ {RESET}").strip()
    param = "-n" if os.name == "nt" else "-c"
    try:
        subprocess.run(["ping", param, "4", host])
    except Exception as e:
        err(f"Ошибка: {e}")


def f_traceroute():
    section("16. Traceroute")
    host = input(f"  {O2}Хост ▸ {RESET}").strip()
    cmd = ["tracert", "-h", "15", host] if os.name == "nt" else ["traceroute", "-m", "15", host]
    try:
        subprocess.run(cmd)
    except Exception as e:
        err(f"Ошибка: {e}")


def f_http_methods():
    section("17. HTTP Methods")
    url = clean_url(input(f"  {O2}URL ▸ {RESET}").strip())
    for m in ["GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD", "TRACE"]:
        try:
            r = requests.request(m, url, timeout=6, verify=False,
                                 headers={"User-Agent": "SOOLPOOL/3.0"})
            color = G if r.status_code < 400 else O if r.status_code < 500 else R
            print(f"  {color}[{m:7}]{RESET} {r.status_code}")
        except Exception:
            print(f"  {R}[{m:7}] ошибка{RESET}")


def f_security_headers():
    section("18. Security Headers Audit")
    url = input(f"  {O2}URL ▸ {RESET}").strip()
    try:
        r = safe_request(clean_url(url))
        checks = {
            "Strict-Transport-Security": "HSTS",
            "Content-Security-Policy": "CSP",
            "X-Frame-Options": "Clickjacking",
            "X-Content-Type-Options": "MIME sniffing",
            "Referrer-Policy": "Referrer policy",
            "Permissions-Policy": "Permissions policy",
        }
        score = 0
        for k, v in checks.items():
            if k in r.headers:
                ok(f"{v}: {r.headers[k][:60]}")
                score += 1
            else:
                warn(f"{v}: ОТСУТСТВУЕТ")
        color = R if score <= 2 else O if score <= 4 else G
        print(f"\n  {color}{BOLD}Оценка: {score}/{len(checks)}{RESET}")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_geoip():
    section("19. GeoIP")
    ip = input(f"  {O2}IP ▸ {RESET}").strip()
    try:
        r = requests.get(f"http://ip-api.com/json/{ip}", timeout=8).json()
        for k, v in r.items():
            print(f"  {O2}{k:12}{RESET}: {v}")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_wayback():
    section("20. Wayback Machine")
    domain = input(f"  {O2}Домен ▸ {RESET}").strip()
    try:
        r = requests.get(
            f"http://archive.org/wayback/available?url={domain}",
            timeout=8).json()
        snap = r.get("archived_snapshots", {}).get("closest")
        if snap:
            ok(f"URL: {snap['url']}")
            ok(f"Дата: {snap['timestamp']}")
        else:
            warn("Снапшоты не найдены")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_zone_transfer():
    section("21. DNS Zone Transfer")
    domain = input(f"  {O2}Домен ▸ {RESET}").strip()
    try:
        ns_records = dns.resolver.resolve(domain, "NS")
        for ns in ns_records:
            ns_host = str(ns).rstrip(".")
            info(f"Пробуем {ns_host}")
            try:
                import dns.query, dns.zone
                z = dns.zone.from_xfr(dns.query.xfr(ns_host, domain, timeout=5))
                ok(f"УСПЕХ! Записи с {ns_host}:")
                for name in z.nodes.keys():
                    print(f"  {GR}└─{RESET} {name}.{domain}")
            except Exception:
                warn(f"{ns_host} — передача запрещена")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_email_validator():
    section("22. Email Validator")
    email = input(f"  {O2}Email ▸ {RESET}").strip()
    loading_animation("Проверка")
    try:
        valid = validate_email(email, check_deliverability=False)
        email = valid.normalized
        ok(f"Синтаксис: ВАЛИДНЫЙ")
        print(f"     {GR}Нормализован:{RESET} {email}")
    except EmailNotValidError as e:
        err(f"Синтаксис: НЕВАЛИДНЫЙ — {e}")
        return

    local, domain = email.rsplit("@", 1)

    mx_ok = False
    try:
        answers = dns.resolver.resolve(domain, "MX", lifetime=5)
        mx_list = sorted([(r.preference, str(r.exchange).rstrip(".")) for r in answers])
        ok(f"MX записи ({len(mx_list)}):")
        for pref, ex in mx_list[:5]:
            print(f"     {GR}└─{RESET} [{pref}] {ex}")
        mx_ok = True
    except Exception:
        warn("MX записи НЕ найдены — почта может не работать")

    try:
        ip = socket.gethostbyname(domain)
        ok(f"A запись: {ip}")
    except Exception:
        warn("A запись не найдена")

    if domain.lower() in DISPOSABLE_DOMAINS:
        err("ТИП: ОДНОРАЗОВЫЙ / ВРЕМЕННЫЙ")
    else:
        ok("Домен не в списке одноразовых")

    suspicious = [k for k in SUSPICIOUS_KEYWORDS if k in local.lower() or k in domain.lower()]
    if suspicious:
        warn(f"Подозрительные ключи: {', '.join(suspicious)}")

    popular = {
        "gmail.com": "Gmail", "googlemail.com": "Gmail",
        "yandex.ru": "Яндекс", "mail.ru": "Mail.ru",
        "outlook.com": "Outlook", "hotmail.com": "Hotmail",
        "yahoo.com": "Yahoo", "icloud.com": "iCloud",
        "protonmail.com": "ProtonMail", "rambler.ru": "Rambler",
    }

    def levenshtein(a, b):
        if a == b:
            return 0
        if len(a) < len(b):
            a, b = b, a
        prev = list(range(len(b) + 1))
        for i, ca in enumerate(a, 1):
            cur = [i]
            for j, cb in enumerate(b, 1):
                cur.append(min(cur[j-1]+1, prev[j]+1, prev[j-1]+(ca != cb)))
            prev = cur
        return prev[-1]

    similar = []
    for legit in popular:
        dist = levenshtein(domain.lower(), legit)
        if 0 < dist <= 2:
            similar.append((legit, dist))
    if similar:
        warn("ПОХОЖ на легитимные домены (фишинг?):")
        for legit, dist in similar:
            print(f"     {O3}⚠ {domain} ≈ {legit} (расстояние {dist}){RESET}")

    print(f"\n  {O3}{'─' * 50}{RESET}")
    if mx_ok and domain.lower() not in DISPOSABLE_DOMAINS and not similar:
        print(f"  {G}{BOLD}▸ ВЕРДИКТ: ЛЕГИТИМНЫЙ{RESET}")
    elif domain.lower() in DISPOSABLE_DOMAINS or similar:
        print(f"  {R}{BOLD}▸ ВЕРДИКТ: ПОДОЗРИТЕЛЬНЫЙ / FAKE{RESET}")
    else:
        print(f"  {O}{BOLD}▸ ВЕРДИКТ: ЧАСТИЧНО ВАЛИДНЫЙ{RESET}")


def f_email_osint():
    section("23. Email OSINT (holehe)")
    if not shutil.which("holehe"):
        err("holehe не установлен. Установи: pip install holehe")
        return
    email = input(f"  {O2}Email ▸ {RESET}").strip()
    loading_animation("Сканируем платформы", 3)
    try:
        proc = subprocess.run(
            ["holehe", email, "--only-used", "--no-color"],
            capture_output=True, text=True, timeout=90,
        )
        output = proc.stdout + proc.stderr
        found = []
        for line in output.splitlines():
            line = line.strip()
            if line.startswith("[+]"):
                found.append(line.replace("[+]", "").strip())
        if found:
            ok(f"Найден на {len(found)} платформах:")
            for p in found:
                print(f"  {G}[+]{RESET} {p}")
        else:
            warn("Регистраций не найдено")
    except subprocess.TimeoutExpired:
        err("Таймаут 90 секунд")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_email_rep():
    section("24. Email Reputation (emailrep.io)")
    email = input(f"  {O2}Email ▸ {RESET}").strip()
    loading_animation("Запрос")
    try:
        r = requests.get(
            f"https://emailrep.io/{email}",
            headers={"User-Agent": "SOOLPOOL-OSINT"},
            timeout=10,
        )
        if r.status_code == 200:
            data = r.json()
            for k, v in data.items():
                if isinstance(v, (dict, list)):
                    print(f"  {O2}{k}{RESET}: {json.dumps(v, ensure_ascii=False)}")
                else:
                    print(f"  {O2}{k}{RESET}: {v}")
        elif r.status_code == 429:
            warn("Rate limit — попробуй позже")
        else:
            err(f"HTTP {r.status_code}")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_hibp():
    section("25. Have I Been Pwned")
    email = input(f"  {O2}Email ▸ {RESET}").strip()
    key = input(f"  {O2}API-ключ HIBP (Enter — без) ▸ {RESET}").strip() or None
    loading_animation("Проверка утечек")
    try:
        headers = {"User-Agent": "SOOLPOOL-OSINT", "hibp-api-key": key or ""}
        r = requests.get(
            f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}",
            headers=headers, timeout=10,
            params={"truncateResponse": "false"},
        )
        if r.status_code == 200:
            breaches = r.json()
            warn(f"Найден в {len(breaches)} утечках:")
            for b in breaches:
                print(f"  {O3}[!]{RESET} {b.get('Name')} — {b.get('Title')}")
                print(f"      {GR}Дата: {b.get('BreachDate')}, записей: {b.get('PwnCount')}{RESET}")
        elif r.status_code == 404:
            ok("Утечек не найдено")
        elif r.status_code == 401:
            err("Требуется API-ключ HIBP")
        elif r.status_code == 429:
            warn("Rate limit")
        else:
            err(f"HTTP {r.status_code}")
    except Exception as e:
        err(f"Ошибка: {e}")


def f_phone_validator():
    section("26. Phone Validator")
    raw = input(f"  {O2}Номер (с +) ▸ {RESET}").strip()
    region = input(f"  {O2}Регион (RU/US/Enter) ▸ {RESET}").strip().upper() or "RU"
    loading_animation("Проверка")
    try:
        num = phonenumbers.parse(raw, region)
    except phonenumbers.NumberParseException as e:
        err(f"Не удалось распарсить: {e}")
        return

    is_valid = phonenumbers.is_valid_number(num)
    is_possible = phonenumbers.is_possible_number(num)
    color = G if is_valid else O if is_possible else R
    status = "ВАЛИДНЫЙ" if is_valid else "ВОЗМОЖНЫЙ" if is_possible else "НЕВАЛИДНЫЙ"
    print(f"  {color}Валидность: {status}{RESET}")

    print(f"\n  {O2}Форматы:{RESET}")
    print(f"     E.164        : {phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.E164)}")
    print(f"     International: {phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.INTERNATIONAL)}")
    print(f"     National     : {phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.NATIONAL)}")
    print(f"     RFC3966      : {phonenumbers.format_number(num, phonenumbers.PhoneNumberFormat.RFC3966)}")

    print(f"\n  {O2}Информация:{RESET}")
    print(f"     Страна код  : +{num.country_code}")
    print(f"     Регион      : {geocoder.description_for_number(num, 'ru') or geocoder.description_for_number(num, 'en')}")
    print(f"     Оператор    : {carrier.name_for_number(num, 'ru') or carrier.name_for_number(num, 'en')}")
    print(f"     Часовой пояс: {', '.join(pn_timezone.time_zones_for_number(num))}")

    ntype = phonenumbers.number_type(num)
    types = {
        0: "FIXED_LINE", 1: "MOBILE", 2: "FIXED_LINE_OR_MOBILE",
        3: "TOLL_FREE", 4: "PREMIUM_RATE", 5: "SHARED_COST",
        6: "VOIP", 7: "PERSONAL_NUMBER", 8: "PAGER",
        9: "UAN", 10: "VOICEMAIL", -1: "UNKNOWN",
    }
    print(f"     Категория   : {types.get(ntype, 'UNKNOWN')}")

    digits = re.sub(r"\D", "", raw)
    print(f"\n  {O2}Анализ паттерна:{RESET}")
    if re.fullmatch(r"(\d)\1+", digits):
        warn("Все цифры одинаковые — вероятно фейк")
    if "1234567" in digits or "7654321" in digits:
        warn("Содержит последовательность — возможно фейк")
    for p in ["0000000", "1111111", "5555555", "9999999"]:
        if p in digits:
            warn("Известный фейковый паттерн")

    print(f"\n  {O3}{'─' * 50}{RESET}")
    if is_valid and ntype in (0, 1, 2):
        print(f"  {G}{BOLD}▸ ВЕРДИКТ: РЕАЛЬНЫЙ НОМЕР{RESET}")
    elif ntype == 6:
        print(f"  {O}{BOLD}▸ ВЕРДИКТ: VoIP НОМЕР{RESET}")
    elif not is_valid:
        print(f"  {R}{BOLD}▸ ВЕРДИКТ: НЕВАЛИДНЫЙ / FAKE{RESET}")
    else:
        print(f"  {O}{BOLD}▸ ВЕРДИКТ: ТРЕБУЕТ ПРОВЕРКИ{RESET}")


def f_phoneinfoga():
    section("27. PhoneInfoga Scan")
    if not shutil.which("phoneinfoga"):
        err("phoneinfoga не установлен")
        return
    number = input(f"  {O2}Номер (с +) ▸ {RESET}").strip()
    clean = number.lstrip("+").replace(" ", "").replace("-", "")
    loading_animation("Скан", 3)
    try:
        proc = subprocess.run(
            ["phoneinfoga", "scan", "-n", clean, "--no-color"],
            capture_output=True, text=True, timeout=90,
        )
        print((proc.stdout + proc.stderr)[:3000])
    except Exception as e:
        err(f"Ошибка: {e}")


def f_phone_dorks():
    section("28. Phone Dorks (ручной поиск)")
    number = input(f"  {O2}Номер ▸ {RESET}").strip()
    clean = re.sub(r"\D", "", number)
    if not clean:
        err("Пустой номер")
        return
    variants = [clean, "+" + clean, number, number.replace("+", "%2B")]
    dorks = []
    for v in set(variants):
        dorks.extend([
            f"https://www.google.com/search?q=%22{v}%22",
            f"https://yandex.ru/search/?text=%22{v}%22",
            f"https://duckduckgo.com/?q=%22{v}%22",
            f"https://www.bing.com/search?q=%22{v}%22",
            f"https://www.facebook.com/search/top?q={v}",
            f"https://twitter.com/search?q=%22{v}%22",
            f"https://www.linkedin.com/search/results/all/?keywords={v}",
            f"https://t.me/s/{v}",
            f"https://vk.com/search?c%5Bq%5D={v}",
            f"https://github.com/search?q={v}&type=users",
        ])
    ok(f"Сгенерировано {len(dorks)} ссылок:")
    for d in dorks:
        print(f"  {GR}└─{RESET} {d}")


MENU = [
    ("WHOIS Lookup",            f_whois),
    ("DNS Records",             f_dns),
    ("IP Information",          f_ip_info),
    ("Reverse DNS",             f_reverse_dns),
    ("HTTP Headers",            f_headers),
    ("SSL Certificate",         f_ssl),
    ("Robots.txt",              f_robots),
    ("Sitemap.xml",             f_sitemap),
    ("Port Scanner",            f_ports),
    ("Subdomain Finder",        f_subdomains),
    ("Website Error Checker",   f_website_errors),
    ("Technologies Detector",   f_technologies),
    ("Email Extractor (site)",  f_emails_extract),
    ("Phone Extractor (site)",  f_phones_extract),
    ("Ping",                    f_ping),
    ("Traceroute",              f_traceroute),
    ("HTTP Methods",            f_http_methods),
    ("Security Headers",        f_security_headers),
    ("GeoIP",                   f_geoip),
    ("Wayback Machine",         f_wayback),
    ("DNS Zone Transfer",       f_zone_transfer),
    ("★ Email Validator",       f_email_validator),
    ("★ Email OSINT (holehe)",  f_email_osint),
    ("★ Email Reputation",      f_email_rep),
    ("★ HIBP Breaches",         f_hibp),
    ("★ Phone Validator",       f_phone_validator),
    ("★ PhoneInfoga Scan",      f_phoneinfoga),
    ("★ Phone Dorks",           f_phone_dorks),
]


def menu():
    while True:
        banner()
        print(f"{O3}  ╭{'─' * 58}╮{RESET}")
        for i, (name, _) in enumerate(MENU, 1):
            star = f"{O3}★{RESET}" if name.startswith("★") else f"{O2}▸{RESET}"
            clean_name = name.replace("★ ", "")
            print(f"{O3}  │{RESET} {O2}[{i:02d}]{RESET} {star} {clean_name:<48}{O3}│{RESET}")
        print(f"{O3}  ╰{'─' * 58}╯{RESET}")
        print(f"  {R}[00] Выход{RESET}")
        choice = input(f"\n  {O2}{BOLD}soolpool ▸{RESET} ").strip()
        if choice in ("0", "00", "exit", "q"):
            typewriter(f"\n  {O2}▸ Выход. До связи, оператор.{RESET}", 0.015)
            break
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(MENU):
                MENU[idx][1]()
            else:
                warn("Неверный пункт")
        except ValueError:
            warn("Введите число")
        input(f"\n  {O}Enter для возврата в меню...{RESET}")


if __name__ == "__main__":
    try:
        if os.name == "nt":
            os.system("title SOOLPOOL v3.0")
            os.system("color 06")
        clear()
        typewriter("  Инициализация SOOLPOOL v3.0", 0.02, O3)
        progress_bar("Загрузка модулей", 1.4)
        progress_bar("Проверка соединения", 0.9)
        time.sleep(0.3)
        menu()
    except KeyboardInterrupt:
        print(f"\n  {R}[!] Прервано{RESET}")
    except Exception as e:
        print(f"  {R}Критическая ошибка: {e}{RESET}")