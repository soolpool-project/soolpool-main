# SOOLPOOL v3.0

OSINT-фреймворк для консоли. Только публичные источники.

## Установка

```bash
chmod +x install.sh
./install.sh
```

## Запуск

```bash
source venv/bin/activate
python soolpool.py
```

## Функции (29)

### Domain/Web
1. WHOIS Lookup
2. DNS Records
3. IP Information
4. Reverse DNS
5. HTTP Headers
6. SSL Certificate
7. Robots.txt
8. Sitemap.xml
9. Port Scanner
10. Subdomain Finder
11. Website Error Checker
12. Technologies Detector
13. Email Extractor (со сайта)
14. Phone Extractor (с сайта)
15. Ping
16. Traceroute
17. HTTP Methods
18. Security Headers
19. GeoIP
20. Wayback Machine
21. DNS Zone Transfer

### Email
22. Email Validator (синтаксис, MX, disposable, тайпсквоттинг)
23. Email OSINT (holehe — регистрации на 120+ платформах)
24. Email Reputation (emailrep.io)
25. HIBP (утечки, нужен API-ключ)
26. GHunt (Google-профиль)

### Phone
27. Phone Validator (валидность, оператор, регион, тип)
28. PhoneInfoga Scan
29. Phone Dorks (ссылки для ручного поиска)

pip3 install requests dnspython python-whois colorama beautifulsoup4 phonenumbers email-validator
python3 soolpool.py