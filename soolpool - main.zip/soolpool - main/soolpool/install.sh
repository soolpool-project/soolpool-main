#!/bin/bash
set -e

echo "▸ Установка SOOLPOOL v3.0"

if [ ! -d "venv" ]; then
    echo "  → Создаём venv..."
    python3 -m venv venv
fi
source venv/bin/activate

echo "  → Устанавливаем pip-пакеты..."
pip install --upgrade pip -q
pip install -r requirements.txt -q

if ! command -v holehe &> /dev/null; then
    echo "  → Устанавливаем holehe..."
    pip install holehe -q
fi

if ! command -v phoneinfoga &> /dev/null; then
    echo "  → Устанавливаем PhoneInfoga..."
    curl -sSL https://raw.githubusercontent.com/sundowndev/phoneinfoga/master/support/scripts/install | bash
fi

if ! command -v ghunt &> /dev/null; then
    echo "  → Устанавливаем GHunt..."
    pip install ghunt -q 2>/dev/null || pip install git+https://github.com/mxrch/GHunt.git -q
fi

if ! command -v sherlock &> /dev/null; then
    echo "  → Устанавливаем Sherlock..."
    pip install sherlock-project -q
fi

echo ""
echo "✓ Установка завершена"
echo "▸ Запуск: source venv/bin/activate && python soolpool.py"